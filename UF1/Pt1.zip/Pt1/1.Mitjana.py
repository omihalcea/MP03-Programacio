num1 = input("Disme un número: ")
num2 = input("Un altre: ")

mig = int(num1) + int(num2)

mitjana = mig // 2

print(mitjana)