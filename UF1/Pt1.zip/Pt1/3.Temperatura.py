celsius = float(input("Disme la temperatura en ºC: "))

fahrenheit = (celsius * 1.8) + 32

print("\nLa temperatura en Farhenheit es " + str(fahrenheit))